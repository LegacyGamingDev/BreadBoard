API Reference    {#breadboard_api_reference}
=============

This document describes all classes, functions, macros and files that make
up the [Breadboard][] library.  This is intended to be used as a reference for
C++ programmers who have made themselves familiar with the
[Programmer's Guide][].

  [Breadboard]: @ref breadboard_index
  [Programmer's Guide]: @ref breadboard_guide_overview
