To build these samples, simply build the root breadboard CMakeLists.txt:
   for Mac OS Xcode: cmake -Dbreadboard_build_samples=ON -GXcode
                     open breadboard.xcodeproj
   for Mac/Linux terminal: cmake -Dbreadboard_build_samples=ON; make


For more information, see "Building" in the documentation.

